# check_lab.py : 프로젝트 폴더가 약속한 모양인지 점검 (코드를 돌리지 않고 구조만 본다)
import glob
import os
import re
import pandas as pd

PREFIX = "ch66_"            # 이 책이 만든 산출물 이름표 (내 프로젝트에서는 바꿔도 된다)
results = []                # (등급, 내용)
def add(ok, text, level="실패"):
    results.append(("통과" if ok else level, text))

# 1) 필수 파일과 폴더
for path in ["README.md", "notes.md", "config.json", "run_all.py", "requirements.txt",
             "docs/question.md", "docs/metrics.md", "data/hr", "result"]:
    add(os.path.exists(path), f"있어야 할 것: {path}")
steps = ["01_check", "02_eda", "03_analysis", "04_verify", "05_report"]
add(all(os.path.exists(f"scripts/{s}.py") for s in steps), "scripts/01~05 다섯 단계 파일")
add(len(glob.glob("data/hr/*.csv")) == 6, "data/hr/ 의 CSV 6개")

# 2) README 의 필수 구역과 가상 데이터 문장
readme = open("README.md", encoding="utf-8").read()
for sec in ["질문과 결론", "폴더 구조", "실행 방법", "설정", "한계", "환경"]:
    add(f"## {sec}" in readme, f"README 구역: {sec}")
add("가상" in readme, "README에 '가상 데이터'라고 밝혔다")

# 3) 일지: 날짜 제목이 3개 이상
dates = re.findall(r"^## \d{4}-\d{2}-\d{2}", open("notes.md", encoding="utf-8").read(), re.M)
add(len(dates) >= 3, f"notes.md 날짜 항목 {len(dates)}개 (3개 이상)")

# 4) 산출물과 개인정보: 직원 단위 파일이 저장소에 올라가지 않게 막혀 있는가
add(os.path.exists("result/" + PREFIX + "report.md"), "보고서 result/" + PREFIX + "report.md")
ignore = open(".gitignore", encoding="utf-8").read().split() if os.path.exists(".gitignore") else []
add("data/" in ignore, ".gitignore 에 data/ 가 있다")
for f in sorted(glob.glob(f"result/{PREFIX}*.csv")):
    cols = pd.read_csv(f, nrows=0).columns
    if "employee_id" in cols:
        add(f in ignore, f"직원 단위 파일 {f} 이 .gitignore 에 있다", level="경고")

for level, text in results:
    print(f"{level} | {text}")
n_fail = sum(1 for lv, _ in results if lv == "실패")
n_warn = sum(1 for lv, _ in results if lv == "경고")
print(f"\n통과 {sum(1 for lv, _ in results if lv == '통과')}, 경고 {n_warn}, 실패 {n_fail}")
if n_warn:
    print("경고는 67장에서 정리한다: 올리기 전에 개인 단위 파일을 막는다.")
