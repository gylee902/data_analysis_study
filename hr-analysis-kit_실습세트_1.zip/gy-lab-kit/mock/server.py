"""GY글로벌 연습용 서버 (40~44장 공용).

파이썬 표준 라이브러리만 쓴다. 터미널에서 'python mock/server.py' 로 켜고,
Ctrl+C 로 끈다. 주소는 http://127.0.0.1:8765 이다.
이 서버의 모든 데이터는 연습을 위해 만든 가짜이고, 외부로 나가지 않는다.
"""
import csv
import datetime as dt
import hashlib
import json
import math
import os
import random
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

PORT = int(os.environ.get("MOCK_PORT", "8765"))
HERE = os.path.dirname(os.path.abspath(__file__))
EMP_CSV = os.path.join(HERE, "..", "data", "hr", "hr_employees.csv")

PRACTICE_KEY = "gy-practice-key"         # 40장 인증 키 연습용
NAVER_ID, NAVER_SECRET = "demo-id", "demo-secret"
QUOTA_ID, QUOTA_SECRET = "quota-id", "quota-secret"   # 3번만 호출 가능
LOGIN_USER, LOGIN_PASS = "demo", "demo-pass"
LOCK = threading.Lock()

# ---------- 서버가 기억하는 상태 (POST /_admin/reset 으로 초기화) ----------
STATE = {}


def reset_state():
    STATE.clear()
    STATE.update(today="2026-07-01", faults={}, quota=None, quota_calls=0,
                 sessions=set(), naver_calls={}, hits=0)


reset_state()

# ---------- 가짜 데이터: 뉴스 ----------
NEWS_TOPICS = ["하반기 채용 일정 안내", "재택근무 제도 개편 설명회", "사내 교육 과정 신규 개설",
               "복지 포인트 사용 안내", "인사 평가 캘린더 공지", "신입 사원 온보딩 소식",
               "건강검진 예약 안내", "육아 지원 제도 FAQ", "직무 순환 공모 안내",
               "사내 멘토링 참가자 모집", "연차 사용 촉진 안내", "조직 문화 설문 결과 공유"]
NEWS_CATS = ["공지", "채용", "교육", "제도"]


def make_news():
    items = []
    for i in range(23):
        d = dt.date(2026, 6, 30) - dt.timedelta(days=i * 2)
        items.append({"id": 23 - i, "title": f"[{NEWS_CATS[i % 4]}] {NEWS_TOPICS[i % 12]}",
                      "date": d.isoformat(), "category": NEWS_CATS[i % 4]})
    return items


NEWS = make_news()      # 최신 글이 먼저

# ---------- 가짜 데이터: 채용공고 ----------
FAMILIES = ["개발", "영업", "생산", "고객지원", "마케팅", "재무"]
ROLES = {"개발": ["백엔드 개발자", "데이터 엔지니어", "프론트엔드 개발자", "QA 엔지니어"],
         "영업": ["법인 영업 담당", "영업 기획", "제휴 영업"],
         "생산": ["생산 관리", "품질 검사", "설비 보전"],
         "고객지원": ["고객 상담 매니저", "기술 지원 엔지니어"],
         "마케팅": ["콘텐츠 마케터", "퍼포먼스 마케터"],
         "재무": ["회계 담당", "자금 담당"]}
LOCS = ["판교", "서울", "부산", "대전"]


def make_jobs(today):
    t = dt.date.fromisoformat(today)
    jobs = []
    for i in range(1, 54):
        fam = FAMILIES[(i * 5) % 6]
        role = ROLES[fam][i % len(ROLES[fam])]
        if i <= 47:
            posted = dt.date(2026, 6, 1) + dt.timedelta(days=(i - 1) * 30 // 46)
        else:
            posted = dt.date(2026, 7, 2)
        if posted > t:
            continue
        status, updated = "모집중", posted
        if i in (5, 12) and t >= dt.date(2026, 7, 2):
            status, updated = "마감", dt.date(2026, 7, 2)
        jobs.append({"job_id": f"HB-2026-{i:03d}", "title": f"{role} ({'신입' if i % 3 == 0 else '경력'})",
                     "job_family": fam, "location": LOCS[i % 4],
                     "employment_type": "계약" if i % 7 == 0 else "정규",
                     "posted_date": posted.isoformat(),
                     "deadline": (posted + dt.timedelta(days=30)).isoformat(),
                     "status": status, "updated_at": updated.isoformat()})
    return jobs


def headcount_table():
    """hr_employees.csv 에서 2026-06-30 재직자 수를 부서별로 센다."""
    cnt = {}
    with open(EMP_CSV, encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            if r["hire_date"] <= "2026-06-30" and (not r["termination_date"] or r["termination_date"] > "2026-06-30"):
                cnt[r["department"]] = cnt.get(r["department"], 0) + 1
    return cnt


# ---------- HTML 조각 ----------
def page(title, body):
    return ("<!DOCTYPE html><html lang='ko'><head><meta charset='utf-8'>"
            f"<title>{title}</title></head><body>{body}</body></html>")


def news_page(n, layout="v1"):
    per = 10
    total_pages = math.ceil(len(NEWS) / per)
    rows = NEWS[(n - 1) * per: n * per]
    li = "".join(f"<li class='news-item'><a class='news-title' href='/news/{x['id']}'>{x['title']}</a>"
                 f"<span class='news-date'>{x['date']}</span></li>" for x in rows)
    if layout == "v2":      # 43장: 사이트가 개편되어 class 이름이 바뀐 모습
        li = "".join(f"<li class='entry'><a class='entry-link' href='/news/{x['id']}'>{x['title']}</a>"
                     f"<time class='entry-date'>{x['date']}</time></li>" for x in rows)
        return page("GY글로벌 인사팀 소식", f"<h1>GY글로벌 인사팀 소식 (연습용, 개편판)</h1><ul class='news-list'>{li}</ul>")
    nav = ""
    if n < total_pages:
        nav = f"<a class='next' href='/news?page={n + 1}'>다음</a>"
    return page("GY글로벌 인사팀 소식", f"<h1>GY글로벌 인사팀 소식 (연습용)</h1><ul class='news-list'>{li}</ul>"
                f"<div class='pager'>{n} / {total_pages} {nav}</div>")


def jobs_page(n):
    jobs = make_jobs(STATE["today"])
    per = 10
    rows = jobs[(n - 1) * per: n * per]
    tr = "".join(f"<tr class='job-row' data-id='{j['job_id']}'><td class='c-id'>{j['job_id']}</td>"
                 f"<td class='c-title'><a href='/jobs/{j['job_id']}'>{j['title']}</a></td>"
                 f"<td class='c-family'>{j['job_family']}</td><td class='c-loc'>{j['location']}</td>"
                 f"<td class='c-deadline'>{j['deadline']}</td></tr>" for j in rows)
    return page("GY글로벌 채용공고", "<h1>GY글로벌 채용공고 (연습용)</h1><table id='job-table'><thead><tr>"
                "<th>공고번호</th><th>공고명</th><th>직군</th><th>근무지</th><th>마감일</th></tr></thead>"
                f"<tbody>{tr}</tbody></table>")


LIVE_PAGE = page("GY글로벌 채용공고(동적)", """<h1>GY글로벌 채용공고 (동적 페이지, 연습용)</h1>
<table id='job-table'><thead><tr><th>공고번호</th><th>공고명</th><th>직군</th></tr></thead><tbody></tbody></table>
<script>
fetch('/api/v1/jobs?page=1&page_size=5').then(r => r.json()).then(d => {
  const tb = document.querySelector('#job-table tbody');
  d.items.forEach(j => { tb.innerHTML += '<tr><td>' + j.job_id + '</td><td>' + j.title + '</td><td>' + j.job_family + '</td></tr>'; });
});
</script>""")

ROBOTS = """# GY글로벌 연습 서버의 robots.txt (연습용)
User-agent: *
Disallow: /private/
Disallow: /members
Crawl-delay: 1

User-agent: BadBot
Disallow: /

Sitemap: http://127.0.0.1:8765/sitemap.xml
"""

LOGIN_FORM = page("로그인", "<h1>GY글로벌 사내 소식 로그인 (연습용)</h1><form method='post' action='/login'>"
                  "<input name='username'><input name='password' type='password'><button>로그인</button></form>")


def month_starts(a, b, unit):
    a, b = dt.date.fromisoformat(a), dt.date.fromisoformat(b)
    out, cur = [], a
    while cur <= b and len(out) < 400:
        out.append(cur.isoformat())
        if unit == "month":
            cur = (cur.replace(day=1) + dt.timedelta(days=32)).replace(day=1)
        elif unit == "week":
            cur += dt.timedelta(days=7)
        else:
            cur += dt.timedelta(days=1)
    return out


def fake_ratio_series(groups, start, end, unit):
    """가짜 검색 비율. 모든 값 중 최댓값이 100이 되도록 맞춘다."""
    periods = month_starts(start, end, unit)
    raw = {}
    for g in groups:
        name = g.get("groupName") or (g.get("name") or "?")
        base = 20 + int(hashlib.md5(name.encode()).hexdigest(), 16) % 40
        rng = random.Random(name)
        raw[name] = [base + rng.random() * 25 for _ in periods]
    mx = max(max(v) for v in raw.values())
    res = []
    for g in groups:
        name = g.get("groupName") or (g.get("name") or "?")
        res.append({"title": name, "keywords": g.get("keywords", g.get("param", [])),
                    "data": [{"period": p, "ratio": round(v / mx * 100, 5)} for p, v in zip(periods, raw[name])]})
    return res


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *a):
        if os.environ.get("MOCK_VERBOSE"):
            sys.stderr.write("%s %s\n" % (self.command, self.path))

    # ----- 응답 도우미 -----
    def send(self, code, body, ctype="text/html; charset=utf-8", extra=None):
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def js(self, code, obj, extra=None):
        self.send(code, json.dumps(obj, ensure_ascii=False), "application/json; charset=utf-8", extra)

    def body_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n) if n else b""
        try:
            return json.loads(raw.decode("utf-8")) if raw else {}
        except ValueError:
            return None

    def body_raw(self):
        n = int(self.headers.get("Content-Length") or 0)
        return self.rfile.read(n).decode("utf-8") if n else ""

    # ----- 공통 흐름 -----
    def do_GET(self):
        self.route("GET")

    def do_POST(self):
        self.route("POST")

    def route(self, method):
        u = urlparse(self.path)
        q = {k: v[-1] for k, v in parse_qs(u.query).items()}
        p = u.path
        with LOCK:
            STATE["hits"] += 1
        try:
            self.dispatch(method, p, q, u.query)
        except BrokenPipeError:
            pass

    def fault(self, p, query):
        """?_fault=500:2 → 같은 주소로 처음 2번은 500 오류. (연습용 장치)"""
        spec = parse_qs(query).get("_fault", [None])[0]
        if not spec:
            return False
        code, times = spec.split(":")
        key = p + "?" + query
        with LOCK:
            n = STATE["faults"].get(key, 0)
            STATE["faults"][key] = n + 1
        if n < int(times):
            hdr = {"Retry-After": "1"} if code == "429" else None
            self.js(int(code), {"error": "fault_injected", "message": f"연습용 오류 {code} ({n + 1}번째)"}, hdr)
            return True
        return False

    def dispatch(self, method, p, q, query):
        # ---- 관리 ----
        if p == "/_admin/reset" and method == "POST":
            with LOCK:
                reset_state()
            return self.js(200, {"ok": True, "today": STATE["today"]})
        if p == "/_admin/today" and method == "POST":
            b = self.body_json() or {}
            STATE["today"] = b.get("date", STATE["today"])
            return self.js(200, {"today": STATE["today"]})
        if p == "/_admin/state":
            return self.js(200, {"today": STATE["today"], "hits": STATE["hits"]})
        # ---- 사이트 ----
        if p == "/":
            return self.send(200, page("GY글로벌 연습 서버", "<h1>GY글로벌 연습 서버</h1><ul><li><a href='/news'>소식</a></li>"
                                        "<li><a href='/jobs'>채용공고</a></li><li><a href='/jobs-live'>채용공고(동적)</a></li></ul>"))
        if p == "/robots.txt":
            return self.send(200, ROBOTS, "text/plain; charset=utf-8")
        if p == "/news":
            n = int(q.get("page", "1") or 1)
            return self.send(200, news_page(max(n, 1), q.get("layout", "v1")))
        if p.startswith("/news/"):
            i = int(p.split("/")[-1])
            it = next((x for x in NEWS if x["id"] == i), None)
            if not it:
                return self.send(404, page("없음", "<h1>404</h1>"))
            return self.send(200, page(it["title"], f"<h1 class='post-title'>{it['title']}</h1>"
                                        f"<p class='post-date'>{it['date']}</p><div class='post-body'>연습용 본문입니다.</div>"))
        if p == "/jobs":
            return self.send(200, jobs_page(max(int(q.get("page", "1") or 1), 1)))
        if p == "/jobs-live":
            return self.send(200, LIVE_PAGE)
        if p.startswith("/private/"):
            return self.send(200, page("비공개", "<p>크롤러가 가져가지 않기로 한 영역(연습용)</p>"))
        if p == "/login":
            if method == "GET":
                return self.send(200, LOGIN_FORM)
            f = {k: v[-1] for k, v in parse_qs(self.body_raw()).items()}
            if f.get("username") == LOGIN_USER and f.get("password") == LOGIN_PASS:
                sid = hashlib.md5(os.urandom(8)).hexdigest()
                STATE["sessions"].add(sid)
                return self.send(302, "", extra={"Location": "/members", "Set-Cookie": f"sessionid={sid}; Path=/; HttpOnly"})
            return self.send(200, page("로그인", "<p class='error'>아이디 또는 비밀번호가 다릅니다.</p>" + LOGIN_FORM))
        if p == "/members":
            ck = self.headers.get("Cookie", "")
            sid = ck.split("sessionid=")[-1].split(";")[0] if "sessionid=" in ck else ""
            if sid not in STATE["sessions"]:
                return self.send(302, "", extra={"Location": "/login"})
            return self.send(200, page("회원 전용", "<h1>회원 전용 페이지 (연습용)</h1><p class='welcome'>로그인했습니다.</p>"))
        if p == "/slow":
            time.sleep(float(q.get("delay", "1")))
            return self.js(200, {"ok": True})
        # ---- 43장 추가: sitemap, RSS, 차단 흉내, 요청 확인용 echo, 검색(POST), 커서 쪽 나눔 ----
        if p == "/sitemap.xml":
            urls = "".join(f"<url><loc>http://127.0.0.1:{PORT}/news/{x['id']}</loc><lastmod>{x['date']}</lastmod></url>"
                           for x in NEWS)
            return self.send(200, "<?xml version='1.0' encoding='UTF-8'?><urlset xmlns='http://www.sitemaps.org/schemas/sitemap/0.9'>"
                             + urls + "</urlset>", "application/xml; charset=utf-8")
        if p == "/news.rss":
            items = "".join(f"<item><title>{x['title']}</title><link>http://127.0.0.1:{PORT}/news/{x['id']}</link>"
                            f"<pubDate>{x['date']}</pubDate></item>" for x in NEWS[:10])
            return self.send(200, "<?xml version='1.0' encoding='UTF-8'?><rss version='2.0'><channel><title>GY글로벌 인사팀 소식(연습용)</title>"
                             + items + "</channel></rss>", "application/rss+xml; charset=utf-8")
        if p == "/blocked":
            return self.send(403, page("접근 제한", "<h1>403 Forbidden</h1><p>자동화된 접근이 제한되었습니다(연습용).</p>"))
        if p == "/challenge":
            return self.send(200, page("잠시만 기다려 주세요", "<h1>사람인지 확인하고 있습니다</h1>"
                                       "<p>브라우저를 확인하는 중입니다. 이 창을 닫지 마세요(연습용 확인 화면).</p>"))
        if p == "/api/v1/echo":
            body = self.body_raw() if method == "POST" else ""
            return self.js(200, {"method": method, "path": p, "query": q, "content_type": self.headers.get("Content-Type"),
                                 "user_agent": self.headers.get("User-Agent"), "body": body})
        if p == "/api/v1/jobs/search":
            if method != "POST":
                return self.js(405, {"error": "method_not_allowed", "message": "이 주소는 POST만 받습니다."}, {"Allow": "POST"})
            ctype = self.headers.get("Content-Type", "")
            if "json" in ctype:
                b = self.body_json()
                if b is None:
                    return self.js(400, {"error": "bad_json", "message": "본문이 올바른 JSON이 아닙니다."})
            else:
                b = {k: v[-1] for k, v in parse_qs(self.body_raw()).items()}
            kw, fam = (b.get("keyword") or "").strip(), b.get("family")
            page_n, size = int(b.get("page", 1)), int(b.get("page_size", 10))
            if size > 20 or size < 1 or page_n < 1:
                return self.js(400, {"error": "bad_request", "message": "page_size는 1~20, page는 1 이상입니다."})
            jobs = make_jobs(STATE["today"])
            if kw:
                jobs = [j for j in jobs if kw in j["title"]]
            if fam:
                jobs = [j for j in jobs if j["job_family"] == fam]
            total = len(jobs)
            return self.js(200, {"query": {"keyword": kw, "family": fam}, "page": page_n, "page_size": size, "total": total,
                                 "items": jobs[(page_n - 1) * size: page_n * size]})
        if p == "/api/v1/notices":     # 커서 방식 쪽 나눔: next_cursor 가 null 이면 끝
            lim = int(q.get("limit", "10"))
            start = int(q.get("cursor", "0") or 0)
            rows = NEWS[start: start + lim]
            nxt = start + lim if start + lim < len(NEWS) else None
            return self.js(200, {"items": rows, "next_cursor": None if nxt is None else str(nxt)})
        # ---- JSON API ----
        if p == "/api/v1/headcount":
            if self.fault(p, query):
                return
            table = headcount_table()
            dept = q.get("dept")
            if dept:
                if dept not in table:
                    return self.js(404, {"error": "not_found", "message": f"없는 부서: {dept}"})
                return self.js(200, {"as_of": "2026-06-30", "dept": dept, "headcount": table[dept]})
            return self.js(200, {"as_of": "2026-06-30", "total": sum(table.values()),
                                 "departments": [{"dept": k, "headcount": v} for k, v in sorted(table.items())]})
        if p == "/api/v1/secure/headcount":
            key = self.headers.get("X-Api-Key")
            if not key:
                return self.js(401, {"error": "unauthorized", "message": "인증 키가 없습니다."})
            if key != PRACTICE_KEY:
                return self.js(401, {"error": "invalid_key", "message": "인증 키가 올바르지 않습니다."})
            return self.js(200, {"as_of": "2026-06-30", "total": sum(headcount_table().values())})
        if p == "/api/v1/quota-demo":
            now = time.time()
            with LOCK:
                if STATE["quota"] and STATE["quota"] > now:
                    wait = math.ceil(STATE["quota"] - now)
                    return self.js(429, {"error": "too_many_requests", "message": "호출 한도를 넘었습니다."},
                                   {"Retry-After": str(max(wait, 1))})
                STATE["quota_calls"] += 1
                if STATE["quota_calls"] > 3:
                    STATE["quota"], STATE["quota_calls"] = now + 1.0, 0
                    return self.js(429, {"error": "too_many_requests", "message": "호출 한도를 넘었습니다."},
                                   {"Retry-After": "1"})
            return self.js(200, {"ok": True, "calls": STATE["quota_calls"]})
        if p == "/api/v1/jobs":
            if self.fault(p, query):
                return
            page_n, size = int(q.get("page", "1")), int(q.get("page_size", "10"))
            if size > 20 or size < 1 or page_n < 1:
                return self.js(400, {"error": "bad_request", "message": "page_size는 1~20, page는 1 이상입니다."})
            jobs = make_jobs(STATE["today"])
            if q.get("updated_since"):
                jobs = [j for j in jobs if j["updated_at"] >= q["updated_since"]]
            if q.get("family"):
                jobs = [j for j in jobs if j["job_family"] == q["family"]]
            total = len(jobs)
            return self.js(200, {"page": page_n, "page_size": size, "total": total,
                                 "total_pages": math.ceil(total / size),
                                 "items": jobs[(page_n - 1) * size: page_n * size]})
        # ---- 가짜 네이버형 API ----
        if p.startswith(("/search/v1/", "/search-trend/v1/", "/shopping/v1/")):
            return self.naver(method, p, q)
        self.js(404, {"error": "not_found", "message": "없는 주소입니다."})

    def naver(self, method, p, q):
        cid = self.headers.get("X-NCP-APIGW-API-KEY-ID")
        sec = self.headers.get("X-NCP-APIGW-API-KEY")
        if (cid, sec) not in ((NAVER_ID, NAVER_SECRET), (QUOTA_ID, QUOTA_SECRET)):
            return self.js(401, {"error": {"errorCode": "MOCK-401", "message": "인증 정보가 없거나 올바르지 않습니다.",
                                           "details": "연습 서버의 가짜 오류 코드입니다."}})
        if cid == QUOTA_ID:
            with LOCK:
                n = STATE["naver_calls"].get(cid, 0) + 1
                STATE["naver_calls"][cid] = n
            if n > 3:
                return self.js(429, {"error": {"errorCode": "MOCK-429", "message": "호출 한도를 넘었습니다.",
                                               "details": "연습 서버의 가짜 오류 코드입니다."}})
        if p == "/search/v1/blog" and method == "GET":
            query = q.get("query")
            if not query:
                return self.js(400, {"errorCode": "MOCK-400", "errorMessage": "query 값이 필요합니다."})
            disp, start = int(q.get("display", "10")), int(q.get("start", "1"))
            if not 1 <= disp <= 100 or not 1 <= start <= 1000:
                return self.js(400, {"errorCode": "MOCK-400", "errorMessage": "display는 1~100, start는 1~1000"})
            total = 137
            items = []
            for i in range(start, min(start + disp, total + 1)):
                items.append({"title": f"<b>{query}</b> 이야기 {i}번째 글(가상)",
                              "link": f"http://127.0.0.1:{PORT}/news/{(i % 23) + 1}",
                              "description": f"<b>{query}</b>에 대한 가상의 블로그 요약 {i}",
                              "bloggername": f"가상블로거{i % 9}", "postdate": f"2026{(i % 9) + 1:02d}{(i % 27) + 1:02d}"})
            return self.js(200, {"lastBuildDate": "Sat, 10 Oct 2026 09:00:00 +0900", "total": total,
                                 "start": start, "display": len(items), "items": items})
        if method == "POST" and p in ("/search-trend/v1/search", "/shopping/v1/categories"):
            b = self.body_json()
            if b is None:
                return self.js(400, {"errMsg": "요청 본문이 JSON이 아닙니다.", "errId": "MOCK-ERR-1"})
            key = "keywordGroups" if p.startswith("/search-trend") else "category"
            groups = b.get(key) or []
            if not groups or len(groups) > (5 if key == "keywordGroups" else 3) or not b.get("startDate") or not b.get("endDate"):
                return self.js(400, {"errMsg": f"{key} 또는 날짜가 올바르지 않습니다.", "errId": "MOCK-ERR-2"})
            unit = b.get("timeUnit", "month")
            return self.js(200, {"startDate": b["startDate"], "endDate": b["endDate"], "timeUnit": unit,
                                 "results": fake_ratio_series(groups, b["startDate"], b["endDate"], unit)})
        self.js(404, {"error": {"errorCode": "MOCK-404", "message": "없는 API입니다."}})


if __name__ == "__main__":
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    srv.daemon_threads = True
    print(f"GY글로벌 연습 서버 시작: http://127.0.0.1:{PORT}  (끄려면 Ctrl+C)", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("서버를 끈다.")
